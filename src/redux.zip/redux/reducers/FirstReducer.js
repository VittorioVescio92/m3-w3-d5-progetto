const initialState = {
  content: [],
};

const firstReducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default firstReducer;
