const MyNav = () => {
  return (
    <div>
      <h1>home</h1>
    </div>
  );
};
export default MyNav;
